function axissimetricocomtorque
clc
close all
clear all
global J Izz Mx
J=input('Informe o momento de inercia transversal comum aos eixos x e y (kg.m^2): ');
Izz=input('Informe o momento de inercia do eixo de simetria (kg.m^2): ');
n=input('Informe a velocidade angular em torno do eixo de simetria - spin (rad/s): ');
Mx=input('Informe o momento de perturbacao em torno do eixo x (N.m): ');
T=input("'Informe o tempo de simulacao (s): ");
wx0=0;wy0=0;
theta1=0;theta2=0;theta3=0;
x0= [wx0;wy0;n;theta1;theta2;theta3];
opt=odeset('RelTol',1e-12,'AbsTol',1e-12,'MaxStep',0.1);
[t,x]=ode45(@dinamica_torquex_axis_simetrico,[0 T],x0,opt);
phi=x(:,4)+pi/2;
theta=x(:,5);
psi=x(:,6)-pi/2;
N=length(t);
phih=zeros(N,1);thetah=phih;psih=phih;
phiw=zeros(N,1);thetaw=phiw;psiw=phiw;
for i=1:N
    C=angle2dcm(x(i,4),x(i,5),x(i,6),'XYZ');
    wb=[x(i,1);x(i,2);x(i,3)];
    Hb=[J*x(i,1);J*x(i,2);Izz*x(i,3)];
    w0=transpose(C)*wb;
    H0=transpose(C)*Hb;
    psiw(i)=atan2(w0(2),w0(1));
    thetaw(i)=atan2(w0(3),sqrt(w0(1)^2+w0(2)^2));
    psih(i)=atan2(H0(2),H0(1));
    thetah(i)=atan2(H0(3),sqrt(H0(1)^2+H0(2)^2));
end
figure
subplot(231);plot(t,x(:,1));grid;xlabel('t(s)');ylabel('w_x(rad/s)');axis tight
subplot(232);plot(t,x(:,2));grid;xlabel('t(s)');ylabel('w_y(rad/s)');axis tight
subplot(233);plot(t,x(:,3));grid;xlabel('t(s)');ylabel('w_z(rad/s)');axis tight
subplot(234);plot(t,x(:,4)*180/pi);grid;xlabel('t(s)');ylabel('\theta_1(°)');axis tight
subplot(235);plot(t,x(:,5)*180/pi);grid;xlabel('t(s)');ylabel('\theta_2(°)');axis tight
subplot(236);plot(t,x(:,6)*180/pi);grid;xlabel('t(s)');ylabel('\theta_3(°)');axis tight
figure
subplot(331);plot(t,phi*180/pi);grid,xlabel('t(s)');ylabel('\phi(°)');axis tight
subplot(332);plot(t,theta*180/pi);grid;xlabel('t(s)');ylabel('\theta(°)');axis tight
subplot(333);plot(t,psi*180/pi);grid;xlabel('t(s)');ylabel('\psi(°)');axis tight
subplot(323);plot(t,psiw*180/pi);grid;xlabel('t(s)');ylabel('\psi_w(°) - guinada de \omega');axis tight
subplot(324);plot(t,thetaw*180/pi);grid;xlabel('t(s)');ylabel('\theta_w(°) - elevacao de \omega');axis tight
subplot(325);plot(t,psih*180/pi);grid;xlabel('t(s)');ylabel('\psi_h(°) - guinada de \omega');axis tight
subplot(326);plot(t,thetah*180/pi);grid;xlabel('t(s)');ylabel('\theta_h(°) - elevacao de \omega');axis tight
mu=Mx/J;lamb=(J-Izz)*n/J;
Ap=mu*J/(lamb*n*Izz);An=mu/(lamb*n);
wp=Izz*n/J;wn=n;
disp('Amplitude da precessao (graus):');
disp(Ap*180/pi);
disp('Amplitude da nutacao (graus):');
disp(An*180/pi);
disp('Frequencia da precessao (rad/s):');
disp(wp);
disp('Frequencia da nutacao (rad/s):');
disp(wn);
end
function xp=dinamica_torquex_axis_simetrico(t,x)
global J Izz Mx
wx=x(1);wy=x(2);wz=x(3);
theta1=x(4);theta2=x(5);theta3=x(6);
My=0;Mz=0;
Ixx=J;Iyy=J;
wxp=(Mx-(Izz-Iyy)*wy*wz)/Ixx;
wyp=(My-(Ixx-Izz)*wz*wx)/Iyy;
wzp=(Mz-(Iyy-Ixx)*wx*wy)/Izz;
theta1p=(wx*cos(theta3)-wy*sin(theta3))/cos(theta2);
theta2p=wx*sin(theta3)+wy*cos(theta3);
theta3p=(-wx*cos(theta3)*sin(theta2)+wy*sin(theta3)*sin(theta2))/cos(theta2)+wz;
xp=[wxp;wyp;wzp;theta1p;theta2p;theta3p];
end