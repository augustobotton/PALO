function axissimetricolivretorque

clc;close all;clear all;
global J Izz wx0 wy0 n theta0
Izz=input('Informe o momento de inercia do eixo de simetria (kg.m^2): ');
J=input('Informe o momento de inercia transversal comum aos eixos x e y (kg.m^2): ');
n=input('Informe a velocidade angular em torno do eixo de simetria - spin (rad/s): ');
wx0=input('Informe a condicao inicial de velocidade angular em torno do eixo x (rad/s):');
wy0=input('Informe a condicao inicial de velocidade angular em torno do eixo y (rad/s): ');
T=input('Informe o tempo de simulacao (s): ');
theta0=atan2(J*sqrt(wx0^2+wy0^2),Izz*n);
p0=[180/pi 3.5 6];
p=fsolve(@equilibrio,p0);
psi0=p(1);
PHIp=p(2);
PSIp=p(3);
disp('Valor da derivada de phi previsto teoricamente rad/s]: ');
disp(Izz*n/(J*cos(theta0)));
disp('Valor da derivada de phi calculado numericamente [rad/s]: ');
disp(PHIp);
disp('Valor da derivada de psi previsto teoricamente [rad/s]: ');
disp((J-Izz)*n/J);
disp('Valor da derivada de psi calculado numericamente [rad/s]: ');
disp(PSIp);
phi0=0; 
x0=[wx0;wy0;n;phi0;theta0;psi0];
opt=odeset('RelTol',1e-12,'AbsTol',1e-12);
[t,x]=ode15s(@dinamica_livre_torque_axis_simetrico,[0 T],x0,opt);
figure
subplot(231);
plot(t,x(:,1));grid;xlabel('t(s)');ylabel('\omega_x(rad/s)');axis tight
subplot(232);
plot(t,x(:,2));grid;xlabel('t(s)');ylabel('\omega_y(rad/s)');axis tight
subplot(233);
plot(t,x(:,3));grid;xlabel('t(s)');ylabel('\omega_z(rad/s)');axis tight
subplot(234);
plot(t,x(:,4)*180/pi);grid;xlabel('t(s)');ylabel('\phi[°]');axis tight
subplot(235);
plot(t,x(:,5)*180/pi);grid;xlabel('t(s)');ylabel('\theta[°]');axis tight
subplot(236);
plot(t,x(:,6)*180/pi);grid;xlabel('t(s)');ylabel('\psi[°]');axis tight
end
function xp=dinamica_livre_torque_axis_simetrico(t,x)
global J Izz
wx=x(1);wy=x(2);wz=x(3);
phi=x(4);theta=x(5);psi=x(6);
Mx=0;My=0;Mz=0;
Ixx=J;Iyy=J;
wxp=(Mx-(Izz-Iyy)*wy*wz)/Ixx;
wyp=(My-(Ixx-Izz)*wz*wx)/Iyy;
wzp=(Mz-(Iyy-Ixx)*wx*wy)/Izz;
phip=(sin(psi)*wx+cos(psi)*wy)/sin(theta);
thetap=cos(psi)*wx-sin(psi)*wy;
psip=(-cos(theta)*sin(psi)*wx-cos(theta)*cos(psi)*wy)/sin(theta)+wz;
xp=[wxp;wyp;wzp;phip;thetap;psip];
end
function eqs=equilibrio(p)
global wx0 wy0 n theta0
psi0=p(1); 
PHIp=p(2); 
PSIp=p(3); 
phip=(sin(psi0)*wx0+cos(psi0)*wy0)/sin(theta0);
thetap=cos(psi0)*wx0-sin(psi0)*wy0;
psip=(-cos(theta0)*sin(psi0)*wx0-cos(theta0)*cos(psi0)*wy0)/sin(theta0)+n;
eqs(1)=phip-PHIp; 
eqs(2)=thetap;
eqs(3)=psip-PSIp; 
end