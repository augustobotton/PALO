function C=euler313pmatriz(E313)
alpha1=E313(1) ;alpha2=E313(2) ;alpha3=E313(3);
C3_a1=[cos(alpha1)  sin(alpha1) 0
       -sin(alpha1) cos(alpha1) 0
       0            0           1];
C1_a2=[1 0            0
       0 cos(alpha2)  sin(alpha2)
       0 -sin(alpha2) cos(alpha2)];
C3_a3= [cos(alpha3)  sin(alpha3) 0
        -sin(alpha3) cos(alpha3) 0
        0            0           1];
C=C3_a3*C1_a2*C3_a1;
end
