function w=velocidadeangular(t)
w=[cos(2*pi*t)
   cos(pi*t)
   cos(0.5*pi*t)];
end