clc
alpha10=0*pi/180;alpha20=45*pi/180;alpha30=0*pi/180;
Euler3130=[alpha10;alpha20;alpha30];
C0=euler313pmatriz(Euler3130);
E3210=matrizpeuler321(C0);
[e,Phi]=matpeixoang(C0);
Q0=[e*sin(Phi/2)
    cos(Phi/2)];
p0=Q0(1:3)/(1+Q0(4));
T=8;
opt=odeset('RelTol',1e-4,'AbsTol',1e-8,'MaxStep',1e-2);
[t1, E321]=ode45('cinematicaeuler321',[0 T],E3210,opt);
N=length(t1);
omega=zeros (N, 3) ;
for i=1:N
omega (i,:) =velocidadeangular(t1(i))';
end
figure (1)
subplot (211) ;plot (t1, omega(: ,1) , t1, omega(: ,2), t1, omega(:,3) ); grid;
xlabel('t [s]');ylabel ('\omega [rad/s]') ;legend ('\omega_x', '\omega_y', '\omega_z') ;
subplot (212) ;plot (t1,E321 (:,1)*180/pi,t1,E321(:,2)*180/pi,t1,E321(:,3)*180/pi) ;
grid; xlabel('t [s]'); ylabel('Ang. Euler 321 [°]'); legend ('\phi', '\theta', '\psi') ;
[t2, E313]=ode45 ('cinematicaeuler313', [0 T],Euler3130,opt);
N=length(t2);
E321_E313=zeros(N,3);
for i=1:N
    C=euler313pmatriz(E313 (i,:));
    E321_E313 (i, : ) =matrizpeuler321(C)'; 
end
figure(2);
subplot(211); plot(t1, omega (: ,1), t1, omega (: ,2), t1, omega (: ,3) ); grid;
xlabel('t [s]'); ylabel ('\omega [rad/s]') ;legend ('\omega_x','\omega_y', '\omega_z') ;
subplot (212); plot (t2, E313(:,1)*180/pi,t2,E313 (:,2)*180/pi,t2,E313 (: ,3)*180/pi) ;
grid;xlabel('t [s]');ylabel ('Ang. Euler 313 [°]');legend ('\alpha l', '\alpha 2', '\alpha 3') ;
xm0=[C0(1,1) ;C0(1,2) ;C0(1,3) ;C0(2,1) ;C0(2,2) ;C0(2,3) ;C0(3,1) ;C0(3,2) ;C0(3,3) ];
[t3, xm]=ode45('cinematicamcd', [0 T], xm0, opt);
N=length(t3);
E321_mcd=zeros(N, 3);
for i=1:N
    C=[xm(i,1) xm(i,2) xm(i,3)
       xm(i,4) xm(i,5) xm(i, 6)
       xm(i,7) xm(i,8) xm(i, 9) ];
    E321_mcd(i,:)=matrizpeuler321(C)';
end
figure (3);
subplot (211) ;plot (t1, omega (: ,1) , t1, omega (:,2) , t1, omega (:,3) ); grid;
xlabel('t (s]'); ylabel ('\omega [rad/s]') ;legend ('\omega_ x', '\omega_ y', '\omega z') ;
subplot (212) ;
plot (t3, xm (: ,1) , t3, xm (: ,2) , t3, xm (: , 3), t3, xm (: , 4) , t3, xm (:, 5), t3, xm (: , 6) , t3, xm (: , 7) , t3, xm (: , 8) , t3, xm (:, 9) ) ;
grid;
xlabel('t [s]'); ylabel ('MCD [-]'); legend('c_11', 'c_12', 'c_13', 'c_21', 'c_22', 'c_23', 'c_31', 'c_32', 'c_33') ;
[t4, quat]=ode45 ('cinematicaquaternio', [0 T],Q0, opt);
N=length(t4);
E321_quat=zeros (N, 3);
for i=1:N
C=quatpmatriz(quat(i,:)');
E321_quat(i,:)=matrizpeuler321(C)';
end
figure (4)
subplot (211) ;plot (t1, omega (:,1), t1, omega (:,2) , t1, omega (:,3) ); grid;
xlabel('t [s]'); ylabel ('\omega [rad/s]') ;legend ('\omega x', '\omega y', '\omega z') ;
subplot (212) ;plot (t4, quat (:,1) , t4, quat (:,2) , t4, quat (:,3) , t4, quat (:, 4) ) ;
grid; xlabel ('t [s]'); ylabel ('quaternio [-]') ;legend('Q_1', 'Q_2', 'Q_3', 'Q_4') ;
[t5, prm]=ode45('cinematicaprm',[0 T],p0, opt);
N=length(t5);
E321_prm=zeros(N, 3);
for i=1:N
    C=prmpmatriz(prm(i,:)');
    E321_prm(i,:)=matrizpeuler321(C)';
end
figure (5);
subplot (211) ;plot (t1, omega (:,1), t1, omega (: ,2), t1, omega (:,3) ); grid;
xlabel('t [s]'); ylabel ('\omega [rad/s]'); legend ('\omega x', '\omega y', '\omega z');
subplot (212) ;plot (t5, prm (: ,1) , t5, prm (:,2), t5, prm(:,3) ) ;
grid; xlabel ('t [s]'); ylabel ('prm [-]') ;legend('p_1','p_2','p_3');
figure(6);
subplot (311) ;plot (t1,E321(:,1) , t2, E321_E313(:,1) , t3, E321_mcd(:,1), t4, E321_quat(:,1), t5, E321_prm(:,1) ) ;
grid;xlabel('t [s]');ylabel ('\phi (rad]') ;legend ('Euler 321', 'Euler 313', 'MCD', 'quaternio', 'PRM') ;
subplot (312) ;plot (t1,E321(:,2) , t2, E321_E313(:,2) , t3, E321_mcd(:,2), t4, E321_quat(:,2), t5, E321_prm(:,2) ) ;
grid;xlabel('t [s]');ylabel ('\theta (rad]') ;legend ('Euler 321', 'Euler 313', 'MCD', 'quaternio', 'PRM') ;
subplot (313) ;plot (t1,E321(:,3) , t2, E321_E313(:,3) , t3, E321_mcd(:,3), t4, E321_quat(:,3), t5, E321_prm(:,3) ) ;
grid;xlabel('t [s]');ylabel ('\psi (rad]') ;legend ('Euler 321', 'Euler 313', 'MCD', 'quaternio', 'PRM') ;
