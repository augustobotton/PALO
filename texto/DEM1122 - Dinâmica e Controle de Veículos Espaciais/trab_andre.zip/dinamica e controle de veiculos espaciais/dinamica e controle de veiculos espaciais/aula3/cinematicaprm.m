function xp=cinematicaprm(t,x)
p=x;
w=velocidadeangular(t);
Sp=[0     -p(3) p(2)
    p(3)  0     -p(1)
    -p(2) p(1)  0];
xp=0.5*(Sp +p*p'+0.5*(1-p'*p)*eye(3,3))*w;
end