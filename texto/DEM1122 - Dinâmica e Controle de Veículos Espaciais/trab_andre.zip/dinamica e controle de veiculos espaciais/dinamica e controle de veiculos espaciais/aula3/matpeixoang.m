function [e,Phi]=matpeixoang(C)
[V,D]=eig(C);
lamb=[D(1,1) D(2,2) D(3,3)];
for i=1:3
    if imag(lamb(i))==0
        iR=i;
    end
    if imag(lamb(i) )>0
        lambC=lamb(i);
    end
end
e=V(:,iR)/norm(V(:,iR));
Phi=phase(lambC);
end