function xp=cinematicaeuler313(t,x)

alpha1=x(1);alpha2=x(2);alpha3=x(3);
w=velocidadeangular(t); 
xp= (1/sin(alpha2)) * [sin(alpha3)              cos(alpha3)               0
                       sin(alpha2)*cos(alpha3)  -sin(alpha2)*sin(alpha3)  0
                       -cos(alpha2)*sin(alpha3) -cos(alpha2)*cos(alpha3)  sin(alpha2)]*w;
end