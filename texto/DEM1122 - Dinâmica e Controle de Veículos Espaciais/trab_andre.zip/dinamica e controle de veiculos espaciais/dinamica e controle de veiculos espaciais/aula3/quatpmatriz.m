function C=quatpmatriz(Q)
q=Q(1:3);
q4=Q(4);
Sq=[0     -q(3) q(2)
    q(3)  0     -q(1)
    -q(2) q(1)  0];
C=(q4^2-q'*q)*eye(3,3)+2*(q*q')-2*q4*Sq;
end