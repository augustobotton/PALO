function C=prmpmatriz(p)
Sp=[0     -p(3) p(2)
    p(3)  0     -p(1)
    -p(2) p(1)  0];
C=eye(3,3)+(4*(p'*p-1)*Sp+8*Sp^2)/(1+p'*p)^2;
end