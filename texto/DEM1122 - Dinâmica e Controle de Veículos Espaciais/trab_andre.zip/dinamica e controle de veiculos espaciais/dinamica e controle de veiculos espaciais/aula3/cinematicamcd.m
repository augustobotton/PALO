function xp=cinematicamcd(t,x)
C= [x(1) x(2) x(3)
    x(4) x(5) x(6)
    x(7) x(8) x(9)];
w=velocidadeangular(t);
Sw=[0     -w(3) w(2)
    w(3)  0     -w(1)
    -w(2) w(1)  0];
Cp=-Sw*C;
xp=[Cp(1,1)
    Cp(1,2)
    Cp(1,3)
    Cp(2,1)
    Cp(2,2)
    Cp(2,3)
    Cp(3,1)
    Cp(3,2)
    Cp(3,3)];
end