function xp=cinematicaquaternio(t,x)
Q=x;
w=velocidadeangular(t);
Sw=[0     -w(3) w(2)
    w(3)  0     -w(1)
    -w(2) w(1)  0];
OM=[-Sw w
    -w' 0];
xp=0.5*OM*Q;
end