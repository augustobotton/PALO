function E321=matrizpeuler321(C)
phi=atan2(C(2,3),C(3,3));
theta=-asin(C(1,3));
psi=atan2(C(1,2),C(1,1));
E321=[phi; theta; psi];
end